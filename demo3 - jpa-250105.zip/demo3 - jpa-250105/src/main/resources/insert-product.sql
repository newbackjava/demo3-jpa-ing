insert into product values (1, 'shoes1', 'funny', 'nike', 1000)
insert into product values (2, 'shoes2', 'funny', 'nike', 1000)
insert into product values (3, 'shoes3', 'funny', 'nike', 1000)

    use shop3;

insert into member
values ("apple", "1234", "apple", "011");

select * from product;

INSERT INTO Product (productid, company, content, name, price) VALUES
                                                                   (1, 'shoes1', 'funny', 'nike', 1000),
                                                                   (2, 'shoes2', 'funny', 'nike', 1000),
                                                                   (3, 'shoes3', 'funny', 'nike', 1000),
                                                                   (4, 'shoes4', 'funny', 'nike', 1000),
                                                                   (5, 'shoes1', 'funny', 'nike', 1000),
                                                                   (6, 'shoes2', 'funny', 'nike', 1000),
                                                                   (7, 'shoes3', 'funny', 'nike', 1000),
                                                                   (8, 'shoes4', 'funny', 'nike', 1000),
                                                                   (9, 'shoes1', 'funny', 'nike', 1000),
                                                                   (10, 'shoes2', 'funny', 'nike', 1000);
